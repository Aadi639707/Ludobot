# Ludo King Style Multiplayer Game

A production-ready, mobile-first Ludo game built with Next.js, Socket.io, and Framer Motion. This application features real-time gameplay, guest sessions, and a classic colorful design.

## Features

- **Real-time Multiplayer**: Powered by Socket.io for synchronized moves.
- **Guest Play**: Instant access without registration (stored in LocalStorage).
- **Google Login**: OAuth integration for persistent accounts (mocked in this build).
- **Responsive Design**: SVG-based board that scales perfectly from mobile to desktop.
- **60FPS Animations**: Smooth token movement and dice rolling using Framer Motion.
- **Classic Logic**: Includes safe squares, capturing mechanics, and extra turns on 6.

## Prerequisites

- Node.js 18.x or higher
- npm or yarn

## Installation

1. Clone the project or download the source.
2. Install dependencies:
    npm install

## Running the Application

This project uses `concurrently` to run both the frontend (Next.js) and the backend (Socket server) simultaneously.

Run the development command:
    npm run dev

- **Frontend**: http://localhost:3000
- **Backend**: http://localhost:3001

## Project Structure

- `app/`: Next.js App Router pages (Login, Lobby, Game).
- `components/`: Reusable React components like `LudoBoard`.
- `server/`: Express and Socket.io server implementation.
- `public/`: Static assets (fonts, icons).

## Game Mechanics

1. **Start**: Players need to roll a 6 to bring a token out of the home base.
2. **Moving**: Tokens move clockwise according to the dice value.
3. **Capture**: Landing on a square occupied by an opponent (not a safe square) sends their token back to their home base.
4. **Safe Squares**: Marked with stars; tokens here cannot be captured.
5. **Winning**: The first player to get all 4 tokens to the center (home) wins the game.

## Troubleshooting

- **Socket Connection Issues**: Ensure the server is running on port 3001. If you change the port, update the socket URL in `app/game/page.js`.
- **Mobile View**: Use Chrome DevTools Device Mode to test the mobile-first responsive layout.
