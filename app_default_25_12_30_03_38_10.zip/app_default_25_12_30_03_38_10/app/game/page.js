"use client";
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter, useSearchParams } from 'next/navigation';
import io from 'socket.io-client';
import { ArrowLeft, Volume2, Settings as SettingsIcon, MessageSquare } from 'lucide-react';
import LudoBoard from '../../components/LudoBoard';

export default function GamePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const mode = searchParams.get('mode');
  
  const [socket, setSocket] = useState(null);
  const [room, setRoom] = useState(null);
  const [rolling, setRolling] = useState(false);
  const [diceValue, setDiceValue] = useState(1);
  const [turn, setTurn] = useState(0); // 0: Red, 1: Blue, 2: Yellow, 3: Green
  const [players, setPlayers] = useState([
    { id: '1', name: 'Player 1', color: 'red', coins: [0, 0, 0, 0], active: true },
    { id: '2', name: 'Player 2', color: 'blue', coins: [0, 0, 0, 0], active: true },
    { id: '3', name: 'Player 3', color: 'yellow', coins: [0, 0, 0, 0], active: true },
    { id: '4', name: 'Player 4', color: 'green', coins: [0, 0, 0, 0], active: true }
  ]);

  useEffect(() => {
    // In a real production app, replace with your server URL
    const newSocket = io('http://localhost:3001');
    setSocket(newSocket);

    const savedUser = JSON.parse(localStorage.getItem('ludo_user') || '{}');
    const roomId = 'room_123'; // Mock room ID

    newSocket.emit('join_room', { roomId, player: savedUser });

    newSocket.on('room_update', (updatedRoom) => {
      setRoom(updatedRoom);
    });

    newSocket.on('dice_rolled', ({ roll, nextTurn }) => {
      setDiceValue(roll);
      setRolling(false);
      // In online mode, we wait for token move to update turn
    });

    return () => newSocket.disconnect();
  }, []);

  const handleRollDice = () => {
    if (rolling) return;
    setRolling(true);
    
    if (socket) {
      socket.emit('roll_dice', { roomId: 'room_123' });
    } else {
      // Local play fallback
      setTimeout(() => {
        const val = Math.floor(Math.random() * 6) + 1;
        setDiceValue(val);
        setRolling(false);
      }, 1000);
    }
  };

  const getActiveColor = () => {
    const colors = ['#DC2626', '#2563EB', '#FCD34D', '#10B981'];
    return colors[turn];
  };

  return (
    <div className="h-screen flex flex-col bg-slate-950 text-white select-none">
      {/* Game Header */}
      <div className="flex items-center justify-between p-4 bg-slate-900 shadow-xl z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => router.push('/lobby')} className="p-2 bg-slate-800 rounded-full">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="font-bold text-sm leading-tight">Match #4829</h2>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest">{mode} Mode</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 bg-slate-800 rounded-full"><MessageSquare size={18} /></button>
          <button className="p-2 bg-slate-800 rounded-full"><Volume2 size={18} /></button>
          <button className="p-2 bg-slate-800 rounded-full"><SettingsIcon size={18} /></button>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 flex flex-col lg:flex-row items-center justify-center p-2 sm:p-4 gap-4 overflow-hidden">
        
        {/* Board Container */}
        <div className="relative w-full max-w-[min(90vw,600px)] aspect-square">
          <LudoBoard turn={turn} players={players} />
        </div>

        {/* Controls Panel */}
        <div className="w-full lg:w-72 flex flex-col gap-4">
          <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 shadow-2xl">
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2 mb-2">
                <div 
                  className="w-4 h-4 rounded-full animate-pulse" 
                  style={{ backgroundColor: getActiveColor() }}
                />
                <span className="font-bold text-lg uppercase tracking-wider">
                  {players[turn].name}&apos;s Turn
                </span>
              </div>

              {/* Dice Component */}
              <motion.div 
                onClick={handleRollDice}
                animate={rolling ? { 
                  rotate: [0, 90, 180, 270, 360],
                  scale: [1, 1.2, 1],
                  x: [0, -10, 10, -10, 0]
                } : {}}
                transition={{ duration: 0.5, repeat: rolling ? Infinity : 0 }}
                className="w-24 h-24 bg-white rounded-2xl shadow-inner flex items-center justify-center cursor-pointer active:scale-90 transition-transform"
              >
                <span className="text-5xl font-black text-slate-900">{diceValue}</span>
              </motion.div>

              <button
                onClick={handleRollDice}
                disabled={rolling}
                className="w-full py-4 rounded-2xl font-black text-xl shadow-lg transition-all active:scale-95"
                style={{ backgroundColor: getActiveColor() }}
              >
                {rolling ? 'ROLLING...' : 'ROLL DICE'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {players.map((p, idx) => (
              <div 
                key={p.id}
                className={`p-3 rounded-2xl border-2 transition-all ${
                  turn === idx ? 'border-white scale-105 bg-slate-800' : 'border-slate-800 bg-slate-900 opacity-60'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: p.color === 'red' ? '#DC2626' : p.color === 'blue' ? '#2563EB' : p.color === 'yellow' ? '#FCD34D' : '#10B981' }} />
                  <span className="text-xs font-bold truncate">{p.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
