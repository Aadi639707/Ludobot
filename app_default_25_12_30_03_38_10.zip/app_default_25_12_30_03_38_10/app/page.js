"use client";
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { LogIn, UserCircle, ShieldCheck, Info } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleGuestLogin = () => {
    setLoading(true);
    const guestId = `guest_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('ludo_user', JSON.stringify({ 
      id: guestId, 
      name: `Guest_${guestId.slice(-4)}`,
      type: 'guest',
      coins: 500
    }));
    setTimeout(() => router.push('/lobby'), 800);
  };

  const handleGoogleLogin = () => {
    // Mock Google Login
    setLoading(true);
    localStorage.setItem('ludo_user', JSON.stringify({ 
      id: 'google_123', 
      name: 'Rahul Sharma',
      email: 'rahul@example.com',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rahul',
      type: 'google',
      coins: 2500
    }));
    setTimeout(() => router.push('/lobby'), 800);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-black">
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md text-center space-y-8"
      >
        <div className="space-y-2">
          <h1 className="text-6xl font-black tracking-tighter">
            <span className="text-ludo-red">L</span>
            <span className="text-ludo-blue">U</span>
            <span className="text-ludo-yellow">D</span>
            <span className="text-ludo-green">O</span>
          </h1>
          <p className="text-slate-400 font-medium">Ultimate Multiplayer Experience</p>
        </div>

        <div className="bg-slate-800/50 p-8 rounded-3xl border border-slate-700 backdrop-blur-xl shadow-2xl space-y-4">
          <button 
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-white text-slate-900 py-4 px-6 rounded-2xl font-bold text-lg hover:bg-slate-100 transition-all active:scale-95 disabled:opacity-50"
          >
            <LogIn size={24} className="text-blue-600" />
            Login with Google
          </button>

          <button 
            onClick={handleGuestLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-slate-700 text-white py-4 px-6 rounded-2xl font-bold text-lg hover:bg-slate-600 transition-all active:scale-95 disabled:opacity-50"
          >
            <UserCircle size={24} />
            Play as Guest
          </button>
          
          <p className="text-xs text-slate-500 pt-4">
            By continuing, you agree to our Terms & Privacy Policy.
          </p>
        </div>

        <div className="flex justify-center gap-6 text-slate-400 text-sm font-medium">
          <a href="#" className="flex items-center gap-1 hover:text-white transition-colors">
            <ShieldCheck size={16} /> Privacy
          </a>
          <a href="#" className="flex items-center gap-1 hover:text-white transition-colors">
            <Info size={16} /> About
          </a>
        </div>
      </motion.div>
    </main>
  );
}
