"use client";
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { 
  Users, UserPlus, Trophy, ShoppingBag, Settings, 
  Gamepad2, Globe, Medal, LogOut, Coins 
} from 'lucide-react';

export default function LobbyPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('ludo_user');
    if (!savedUser) {
      router.push('/');
    } else {
      setUser(JSON.parse(savedUser));
    }
  }, [router]);

  if (!user) return null;

  const menuItems = [
    { id: 'online', name: 'Play Online', icon: Globe, color: 'bg-ludo-blue', route: '/game?mode=online' },
    { id: 'local', name: 'Pass & Play', icon: Gamepad2, color: 'bg-ludo-green', route: '/game?mode=local' },
    { id: 'friends', name: 'With Friends', icon: UserPlus, color: 'bg-ludo-red', route: '/game?mode=friends' },
    { id: 'tourney', name: 'Tournaments', icon: Trophy, color: 'bg-ludo-yellow', route: '#' },
    { id: 'leader', name: 'Leaderboard', icon: Medal, color: 'bg-purple-600', route: '#' },
    { id: 'shop', name: 'Store', icon: ShoppingBag, color: 'bg-pink-600', route: '#' },
  ];

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      {/* Top Header */}
      <header className="p-4 flex items-center justify-between bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-ludo-red via-ludo-yellow to-ludo-green flex items-center justify-center font-black">L</div>
          <span className="font-bold text-xl hidden sm:inline">Ludo Pro</span>
        </div>

        <div className="flex items-center gap-4">
          <div className="bg-slate-900 px-3 py-1.5 rounded-full border border-slate-700 flex items-center gap-2">
            <Coins size={18} className="text-yellow-400" />
            <span className="font-bold text-sm">{user.coins}</span>
          </div>
          
          <div className="flex items-center gap-2 bg-slate-700/50 p-1 pr-3 rounded-full">
            <img 
              src={user.image || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.id}`} 
              className="w-8 h-8 rounded-full bg-slate-600"
              alt="Profile"
            />
            <span className="text-sm font-bold truncate max-w-[80px]">{user.name}</span>
          </div>
          
          <button 
            onClick={() => { localStorage.clear(); router.push('/'); }}
            className="p-2 hover:bg-slate-700 rounded-full transition-colors"
          >
            <LogOut size={20} className="text-slate-400" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 flex flex-col items-center justify-center max-w-4xl mx-auto w-full">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 w-full">
          {menuItems.map((item, index) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => router.push(item.route)}
              className={`${item.color} p-6 rounded-3xl shadow-lg hover:brightness-110 active:scale-95 transition-all flex flex-col items-center gap-4 text-white group`}
            >
              <div className="p-4 bg-white/20 rounded-2xl group-hover:scale-110 transition-transform">
                <item.icon size={32} />
              </div>
              <span className="font-bold text-lg">{item.name}</span>
            </motion.button>
          ))}
        </div>

        {/* Guest Warning */}
        {user.type === 'guest' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-8 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-2xl flex items-center gap-3 text-yellow-500"
          >
            <Settings size={20} className="animate-spin-slow" />
            <p className="text-sm font-medium">Guest data is not saved. Login with Google to save progress!</p>
          </motion.div>
        )}
      </main>

      <footer className="p-4 text-center text-slate-500 text-xs">
        v1.0.4 Premium Multiplayer • Stable Build
      </footer>
    </div>
  );
}
