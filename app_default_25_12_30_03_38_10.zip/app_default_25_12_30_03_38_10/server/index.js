const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

const rooms = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('join_room', ({ roomId, player }) => {
    socket.join(roomId);
    
    if (!rooms.has(roomId)) {
      rooms.set(roomId, {
        id: roomId,
        players: [],
        gameState: 'waiting',
        currentTurn: 0,
        diceValue: 1,
        boardState: {} // Simplified for this example
      });
    }

    const room = rooms.get(roomId);
    if (room.players.length < 4) {
      const playerWithId = { ...player, socketId: socket.id, color: getAvailableColor(room) };
      room.players.push(playerWithId);
      io.to(roomId).emit('room_update', room);
    }
  });

  socket.on('roll_dice', ({ roomId }) => {
    const room = rooms.get(roomId);
    if (!room) return;

    const roll = Math.floor(Math.random() * 6) + 1;
    room.diceValue = roll;
    
    io.to(roomId).emit('dice_rolled', { roll, nextTurn: room.currentTurn });
  });

  socket.on('move_token', ({ roomId, tokenId, steps }) => {
    const room = rooms.get(roomId);
    if (!room) return;

    // Logic for next turn
    if (room.diceValue !== 6) {
      room.currentTurn = (room.currentTurn + 1) % room.players.length;
    }
    
    io.to(roomId).emit('token_moved', { tokenId, steps, nextTurn: room.currentTurn });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

function getAvailableColor(room) {
  const colors = ['red', 'blue', 'yellow', 'green'];
  const usedColors = room.players.map(p => p.color);
  return colors.find(c => !usedColors.includes(c)) || 'red';
}

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Socket server running on port ${PORT}`);
});
