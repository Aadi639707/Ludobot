"use client";
import React from 'react';
import { motion } from 'framer-motion';

const LudoBoard = ({ turn, players }) => {
  // SVG coordinates and segments logic
  // Viewbox 600x600. Each cell is 40x40 (15x15 grid)
  const cellSize = 40;

  const House = ({ color, x, y }) => {
    const colorMap = {
      red: '#DC2626',
      blue: '#2563EB',
      yellow: '#FCD34D',
      green: '#10B981'
    };
    return (
      <g transform={`translate(${x * cellSize}, ${y * cellSize})`}>
        <rect width={cellSize * 6} height={cellSize * 6} fill={colorMap[color]} />
        <rect x={cellSize} y={cellSize} width={cellSize * 4} height={cellSize * 4} fill="white" rx="10" />
        {/* Token base circles */}
        {[
          { cx: 2, cy: 2 }, { cx: 4, cy: 2 },
          { cx: 2, cy: 4 }, { cx: 4, cy: 4 }
        ].map((pos, i) => (
          <circle key={i} cx={pos.cx * cellSize} cy={pos.cy * cellSize} r={cellSize / 1.5} fill={colorMap[color]} opacity="0.4" />
        ))}
      </g>
    );
  };

  return (
    <svg viewBox="0 0 600 600" className="w-full h-full rounded-xl overflow-hidden shadow-2xl bg-white">
      {/* Background Grid Lines */}
      <defs>
        <pattern id="grid" width={cellSize} height={cellSize} patternUnits="userSpaceOnUse">
          <path d={`M ${cellSize} 0 L 0 0 0 ${cellSize}`} fill="none" stroke="#e2e8f0" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="600" height="600" fill="url(#grid)" />

      {/* Houses */}
      <House color="red" x={0} y={0} />
      <House color="green" x={9} y={0} />
      <House color="blue" x={0} y={9} />
      <House color="yellow" x={9} y={9} />

      {/* Center Square */}
      <g transform={`translate(${6 * cellSize}, ${6 * cellSize})`}>
        <path d={`M 0 0 L ${cellSize * 1.5} ${cellSize * 1.5} L 0 ${cellSize * 3} Z`} fill="#2563EB" />
        <path d={`M 0 0 L ${cellSize * 3} 0 L ${cellSize * 1.5} ${cellSize * 1.5} Z`} fill="#DC2626" />
        <path d={`M ${cellSize * 3} 0 L ${cellSize * 3} ${cellSize * 3} L ${cellSize * 1.5} ${cellSize * 1.5} Z`} fill="#10B981" />
        <path d={`M 0 ${cellSize * 3} L ${cellSize * 3} ${cellSize * 3} L ${cellSize * 1.5} ${cellSize * 1.5} Z`} fill="#FCD34D" />
      </g>

      {/* Path Highlighting - Simplified for visual representation */}
      <rect x={cellSize * 6} y={cellSize * 1} width={cellSize} height={cellSize} fill="#DC2626" rx="4" opacity="0.3" />
      <rect x={cellSize * 13} y={cellSize * 6} width={cellSize} height={cellSize} fill="#10B981" rx="4" opacity="0.3" />
      <rect x={cellSize * 8} y={cellSize * 13} width={cellSize} height={cellSize} fill="#FCD34D" rx="4" opacity="0.3" />
      <rect x={cellSize * 1} y={cellSize * 8} width={cellSize} height={cellSize} fill="#2563EB" rx="4" opacity="0.3" />

      {/* Safe Square Stars */}
      {[
        { x: 1, y: 6 }, { x: 2, y: 8 }, { x: 6, y: 13 }, { x: 8, y: 12 },
        { x: 13, y: 8 }, { x: 12, y: 6 }, { x: 8, y: 1 }, { x: 6, y: 2 }
      ].map((pos, i) => (
        <text key={i} x={pos.x * cellSize + 8} y={pos.y * cellSize + 30} className="text-2xl" fill="#cbd5e1">★</text>
      ))}

      {/* Player Tokens (Render 4 per player in their homes) */}
      {players.map((p, pIdx) => (
        <g key={p.id}>
          {[0,1,2,3].map((tIdx) => {
            // Home positions
            const homeX = p.color === 'red' || p.color === 'blue' ? 1.5 : 10.5;
            const homeY = p.color === 'red' || p.color === 'green' ? 1.5 : 10.5;
            const offsetX = (tIdx % 2) * 2;
            const offsetY = Math.floor(tIdx / 2) * 2;

            return (
              <motion.g 
                key={tIdx}
                initial={{ x: (homeX + offsetX) * cellSize, y: (homeY + offsetY) * cellSize }}
                whileHover={{ scale: 1.1 }}
                className="cursor-pointer"
              >
                <circle r={cellSize / 2.2} fill="rgba(0,0,0,0.2)" cy={4} />
                <circle 
                  r={cellSize / 2.5} 
                  fill={p.color === 'red' ? '#DC2626' : p.color === 'blue' ? '#2563EB' : p.color === 'yellow' ? '#FCD34D' : '#10B981'} 
                  stroke="white" 
                  strokeWidth="3"
                />
              </motion.g>
            );
          })}
        </g>
      ))}
    </svg>
  );
};

export default LudoBoard;
